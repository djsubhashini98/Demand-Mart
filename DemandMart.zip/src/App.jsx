export default function App() {
  return (
    <div style={{textAlign:'center',marginTop:'50px'}}>
      <h1>DemandMart</h1>
      <p>Your AI powered affiliate store is ready.</p>
    </div>
  )
}
