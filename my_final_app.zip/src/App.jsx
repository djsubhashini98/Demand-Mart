export default function App() {
  return (
    <div style={{ fontFamily: 'sans-serif', padding: 20 }}>
      <h1>My Final App</h1>
      <p>This is the generated app you requested.</p>
    </div>
  );
}
